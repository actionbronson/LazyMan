Direct usage:
Run Streamlink.exe and type the desired arguments

Usage from cmd:
Streamlink.exe ARGUMENTS

Notes:
-To disable CMD hints create a file named 'NO_CMD_HINTS'
-For more info visit https://github.com/streamlink/streamlink or https://streamlink.github.io
-For issues visit https://github.com/streamlink/streamlink-portable/issues